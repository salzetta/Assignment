/*:
 ## Exercise - Create Functions
 
 Write a function called `introduceMyself` that prints a brief introduction of yourself. Call the function and observe the printout.
 */
func introduceMyself() {
    print("Hi I'm marco")
}
introduceMyself()

/*:
 Write a function called `magicEightBall` that generates a random number and then uses either a switch statement or if-else-if statements to print different responses based on the random number generated. `let randomNum = Int.random(in: 0...4)` will generate a random number from 0 to 4, after which you can print different phrases corresponding to the number generated. Call the function multiple times and observe the different printouts.
 */
func magicEightBall() {
    let rand = Int.random(in: 0...4)
    switch rand {
    case 0:
        print("Don't eat that salmon in your fridge it's got the salmonella")
    case 1:
        print("You'll meet the love of your life soon")
    case 2:
        print("Your friends are conspiring against you")
    case 3:
        print("there's someone living in your walls")
    case 4:
        print("You should get a cat")
    default:
        print("")
    }
}
magicEightBall()
magicEightBall()
magicEightBall()
magicEightBall()
//: page 1 of 6  |  [Next: App Exercise - A Functioning App](@next)
